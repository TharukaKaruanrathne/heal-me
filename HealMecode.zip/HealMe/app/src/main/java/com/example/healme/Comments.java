package com.example.healme;

public class Comments {
    String postid,comment,username,date,time,url;

    public Comments() {
    }

    public Comments(String postid, String comment, String username, String date, String time, String url) {
        this.postid = postid;
        this.comment = comment;
        this.username = username;
        this.date = date;
        this.time = time;
        this.url = url;
    }

    public String getPostid() {
        return postid;
    }

    public void setPostid(String postid) {
        this.postid = postid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
