package com.example.healme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Belal on 10/18/2017.
 */

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ProductViewHolder> {


    private Context mCtx;
    private List<Comments> CommentList;
    private String RetriveImgLocation = "https://"+AndroidUtils.IP+"/loginRegister/";


    private String PostComment = "https://"+AndroidUtils.IP+"/loginRegister/PostComment.php";




    public CommentAdapter(Context mCtx, List<Comments> commentList) {
        this.mCtx = mCtx;
        this.CommentList = commentList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.comments, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        Comments post = CommentList.get(position);

        holder.usernam.setText(post.getUsername());
        holder.comment.setText(post
                .getComment());

       Glide.with(mCtx)
                .load(post.getUrl())
                .into(holder.userimg);


    }



    @Override
    public int getItemCount() {
        return CommentList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView usernam,comment;
        CircleImageView userimg;
        public ProductViewHolder(View itemView) {
            super(itemView);
userimg = itemView.findViewById(R.id.commentpersonimg);
usernam = itemView.findViewById(R.id.commenteduser);
            comment = itemView.findViewById(R.id.comment);



        }
    }
}