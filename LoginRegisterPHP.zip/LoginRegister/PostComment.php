<?php

if (isset($_POST['postid'])&&isset($_POST['comment'])&&isset($_POST['username'])&&isset($_POST['date'])&&isset($_POST['time'])&&isset($_POST['url'])) {
		
$conn = mysqli_connect('localhost', 'root', '1234', 'healme');

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}



$userid =  $_POST['postid'];
$comment =  $_POST['comment'];
$username =  $_POST['username'];
$url =  $_POST['url'];
$date =  $_POST['date'];
$time =  $_POST['time'];



$sql = "INSERT INTO postcomment (postid,comment,username,date,time,url)
VALUES ('".$userid."','".$comment."','".$username."','".$date."','".$time."','".$url."')";

if (mysqli_query($conn, $sql)) {
  echo "success";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

	  
	  
	  
    } 
 
?>