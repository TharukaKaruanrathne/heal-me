package com.example.healme;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    String Url = "https://"+AndroidUtils.IP+"/loginRegister/login.php";
    private EditText username, password;
    Button buttonLogin;
    boolean isLoggedIn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);

        // Add a click listener to the login button
        buttonLogin.setOnClickListener(v -> {
            // Call the method for login handling
            handleLogin();
        });
    }

    private void handleLogin() {
        String enteredUsername = username.getText().toString();
        String enteredPassword = password.getText().toString();

        // Check if fields are empty
        if (TextUtils.isEmpty(enteredUsername) || TextUtils.isEmpty(enteredPassword)) {
            showMessage("Please fill in both Username and Password fields", true);
            return;
        }

        loginUsingVolley(enteredUsername, enteredPassword);
    }

    private void showMessage(String message, boolean isError) {
        TextView messageTextView = findViewById(R.id.messageTextView);
        messageTextView.setText(message);

        if (isError) {
            messageTextView.setTextColor(Color.RED);
        } else {
            messageTextView.setTextColor(Color.GREEN); // Change to a suitable color for success messages
        }

        messageTextView.setVisibility(View.VISIBLE);
    }

    private void loginUsingVolley(String username, String password) {
       HttpsTrustManager.allowAllSSL();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.matches("Success")){
                   Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
intent.putExtra("username",username);
startActivity(intent);

                    finish();

                }else{
                    AndroidUtils.makeToast(getApplicationContext(),response.toString());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            protected Map<String, String> getParams() throws AuthFailureError {
            // Send username and password to the server
            Map<String, String> hashmap = new HashMap<>();
            hashmap.put("user_name", username);
            hashmap.put("password", password);
            return hashmap;
        }
    };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
}
