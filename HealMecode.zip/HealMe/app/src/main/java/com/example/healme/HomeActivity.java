package com.example.healme;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {
TextView loguser;
EditText Whtson;
Button post; Button btnHome;
RecyclerView recyclerView,commentrec;
ImageView postImg;
    Uri selectedImageUri;
Button browseimg;
Bitmap bitmap;
    private String Url = "https://"+AndroidUtils.IP+"/loginRegister/InsertPost.php";
    private String LatesPost = "https://"+AndroidUtils.IP+"/loginRegister/LatesPost.php";

    private String PostWithImage = "https://"+AndroidUtils.IP+"/loginRegister/PostWithImage.php";



    List<Post> PostList;

    int SELECT_PICTURE = 200;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        username= getIntent().getExtras().getString("username");
        //
        recyclerView = findViewById(R.id.re);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //initializing the productlist
        PostList = new ArrayList<>();
        loadPosts();


        loguser = findViewById(R.id.loginuser);
        Whtson = findViewById(R.id.whtsonmind);
        post = findViewById(R.id.postbtn);

        Button btnHome = findViewById(R.id.btn_home);// navigate button
       // Button btnViewProfile = findViewById(R.id.viewprofile);// navigate button
        Button btnCreatePost = findViewById(R.id.createpost);// navigate button
        Button btnLogout = findViewById(R.id.logout);// navigate button


        loguser.setText(username);
        postImg = findViewById(R.id.selectedimage);




        browseimg = findViewById(R.id.browseimage);
        post.setEnabled(false);
        post.setBackgroundColor(getResources().getColor(R.color.gray));
        Whtson.addTextChangedListener(new TextWatcher() {
            @Override
            // when there is no text added
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!Whtson.getText().toString().equals("")){
                    post.setEnabled(true);
                    post.setBackgroundColor(getResources().getColor(R.color.purple));

                }
                else{
                    post.setEnabled(false);
                    post.setBackgroundColor(getResources().getColor(R.color.gray));

                }
            }

        });

        browseimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageChooser();
            }
        });
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (null!=selectedImageUri){


                    PostItem(Whtson.getText().toString(),bitmap);
                }else{
                    PostItem(Whtson.getText().toString());
                }

            }
        });

        //bottom navigator
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // No need to navigate to the same activity
            }
        });

       /* btnViewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Replace ProfileActivity with the actual name of your profile activity
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        btnCreatePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Replace CreatePostActivity with the actual name of your create post activity
                Intent intent = new Intent(HomeActivity.this, CreatePostActivity.class);
                startActivity(intent);
            }
        });*/

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Close the current activity
            }
        });


    }

    private void PostItem(String post, Bitmap bm) {
        try{
            final String Base64Img;
            ByteArrayOutputStream byteArrayOutputStream;
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (bm!=null){
                bm.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
                byte[] byts=byteArrayOutputStream.toByteArray();
                Base64Img = Base64.encodeToString(byts,Base64.DEFAULT);

                HttpsTrustManager.allowAllSSL();
                StringRequest stringRequest = new StringRequest(Request.Method.POST, PostWithImage, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.matches("success")){
                            AndroidUtils.makeToast(getApplicationContext(),"Saved Success");
                            loadPosts();
                            Whtson.setText("");
                            selectedImageUri = null;
                            bitmap = null;
                            postImg.setImageResource(android.R.color.transparent);
//                    startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
//                    finish();

                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        AndroidUtils.makeToast(getApplicationContext(),error.getMessage());
                    }
                }){
                    @NonNull
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        // Send username and password to the server
                        Map<String, String> hashmap = new HashMap<>();
                        hashmap.put("POSTTEXT", post);
                        hashmap.put("image", Base64Img);
                        hashmap.put("user_name", username);
                        hashmap.put("date", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                        hashmap.put("time", new SimpleDateFormat("hh:mm:ss a").format(new Date()));

                        return hashmap;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    private void imageChooser() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        // pass the constant to compare it
        // with the returned requestCode
        startActivityForResult(Intent.createChooser(i, "Select Picture"), SELECT_PICTURE);

    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            // compare the resultCode with the
            // SELECT_PICTURE constant
            if (requestCode == SELECT_PICTURE) {
                // Get the url of the image from data
                 selectedImageUri = data.getData();
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),selectedImageUri);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                if (null != selectedImageUri) {
                    // update the preview image in the layout
                    postImg.setImageURI(selectedImageUri);
                    postImg.setMaxWidth(600);
                    postImg.setMaxHeight(600);
                    post.setEnabled(true);
                    post.setBackgroundColor(getResources().getColor(R.color.purple));



                }
            }
        }
    }
    public static String getPath(Context context, Uri uri ) {
        String result = null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver( ).query( uri, proj, null, null, null );
        if(cursor != null){
            if ( cursor.moveToFirst( ) ) {
                int column_index = cursor.getColumnIndexOrThrow( proj[0] );
                result = cursor.getString( column_index );
            }
            cursor.close( );
        }
        if(result == null) {
            result = "Not found";
        }
        return result;
    }
    private void loadPosts() {
        HttpsTrustManager.allowAllSSL();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, LatesPost,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                          //
                           PostList.clear();
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject posts = array.getJSONObject(i);

                                //adding the product to product list
                                PostList.add(new Post(

                                        posts.getString("content"),
                                        posts.getString("user_name"),

                                        posts.getString("url"),
                                        posts.getString("postid")


                                        ));
                            }

                            //creating adapter object and setting it to recyclerview

                            PostAdapter adapter = new PostAdapter(HomeActivity.this, PostList);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }



    private void PostItem(String whtsonurmind) {
        HttpsTrustManager.allowAllSSL();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.matches("success")){
                    AndroidUtils.makeToast(getApplicationContext(),"Saved Success");
                    loadPosts();
                    Whtson.setText("");
//                    startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
//                    finish();
//                    Clear();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                AndroidUtils.makeToast(getApplicationContext(),error.getMessage());
            }
        }){
            @NonNull
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send username and password to the server
                Map<String, String> hashmap = new HashMap<>();
                hashmap.put("POSTTEXT", whtsonurmind);
                hashmap.put("user_name", username);





                return hashmap;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    @Override
    protected void onStart() {
        super.onStart();
        loadPosts();
    }

//    btnHome.setOnClickListener(new View.OnClickListener(){
//        public void onClick(View v){
//        // No need to navigate to the same activity
//
//        });
//
//    }
}