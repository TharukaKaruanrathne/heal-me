<?php

 $conn = mysqli_connect('localhost', 'root', '1234', 'healme');
 //creating a query

  $postid =  $_POST['postid'];
 $stmt = $conn->prepare("SELECT postid,comment,username,date,time,url FROM postcomment where postid='".$postid."' ");
 
 //executing the query 
 $stmt->execute();
 
 $stmt->bind_result($postid,$comment,$username,$date,$time,$url);
 
 
 $posts = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['postid'] = $postid;  
 $temp['comment'] = $comment; 

 $temp['username'] = $username; 
 $temp['date'] = $date; 
 $temp['time'] = $time; 
 
 
 $temp['url'] = $url; 
 
 
 
 array_push($posts, $temp);
 }
 echo json_encode($posts);
 
 
?>