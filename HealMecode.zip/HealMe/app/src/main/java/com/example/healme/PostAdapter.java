package com.example.healme;

import android.content.Context;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ProductViewHolder> {
RecyclerView commentrec;

    private Context mCtx;
    private List<Post> postList;
    private String RetriveImgLocation = "https://"+AndroidUtils.IP+"/loginRegister/";

public String postidnew;
    private String PostComment = "https://"+AndroidUtils.IP+"/loginRegister/PostComment.php";

    private String LatesComments = "https://"+AndroidUtils.IP+"/loginRegister/LatesComments.php";

    List<Comments>Commntlist;


    public PostAdapter(Context mCtx, List<Post> postLis) {
        this.mCtx = mCtx;
        this.postList = postLis;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.posts, null);
        commentrec= view.findViewById(R.id.commentsre);
        commentrec.setLayoutManager(new LinearLayoutManager(view.getContext()));

        //initializing the productlist
        Commntlist = new ArrayList<>();
        loadLatesComment(view);


        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        Post post = postList.get(position);
postidnew = post.getPostid();

       Glide.with(mCtx)
                .load(RetriveImgLocation+post.url)
                .into(holder.imageView);


        holder.posttext.setText(post.getContent());
        holder.postuser.setText(post.getUser_name());
        holder.id.setText(post.getPostid());
        holder.proedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu pm =new PopupMenu(mCtx,v);
                pm.inflate(R.menu.editdel);
                pm.show();

            }
        });
        holder.sendcomnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!holder.commenttext.getText().toString().matches("")){
                    AddComment(post.getUser_name(),RetriveImgLocation+post.url,post.getPostid(),holder.commenttext.getText().toString());
                }
            }
        });
//        holder.textViewRating.setText(String.valueOf(product.getRating()));
//        holder.textViewPrice.setText(String.valueOf(product.getPrice()));
    }

    private void AddComment(String userName, String url, String postid, String s) {


        try{
            HttpsTrustManager.allowAllSSL();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, PostComment, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    if(response.matches("success")){


//                    startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
//                    finish();

                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    AndroidUtils.makeToast(mCtx.getApplicationContext(), error.getMessage());
                }
            }){
                @NonNull
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    // Send username and password to the server
                    Map<String, String> hashmap = new HashMap<>();
                    hashmap.put("postid", postid);
                    hashmap.put("comment", s);
                    hashmap.put("username", userName);
                    hashmap.put("url", url);
                    hashmap.put("date", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                    hashmap.put("time", new SimpleDateFormat("hh:mm:ss a").format(new Date()));







                    return hashmap;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(mCtx.getApplicationContext());
            requestQueue.add(stringRequest);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void loadLatesComment(View view) {

            HttpsTrustManager.allowAllSSL();
            StringRequest stringRequest = new StringRequest(Request.Method.GET, LatesComments,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                //converting the string to json array object
                                JSONArray array = new JSONArray(response);

                                //traversing through all the object
                                //
                                Commntlist.clear();
                                for (int i = 0; i < array.length(); i++) {

                                    //getting product object from json array
                                    JSONObject posts = array.getJSONObject(i);

                                    //adding the product to product list
                                    Commntlist.add(new Comments(

                                            posts.getString("postid"),
                                            posts.getString("comment"),
                                            posts.getString("username"),
                                            posts.getString("date"),
                                            posts.getString("time"),
                                            posts.getString("url")




                                            ));
                                }

                                //creating adapter object and setting it to recyclerview

                                CommentAdapter adapter = new CommentAdapter(view.getContext(), Commntlist);
                                commentrec.setAdapter(adapter);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }){
                protected Map<String, String> getParams() throws AuthFailureError {
                    // Send username and password to the server
                    Map<String, String> hashmap = new HashMap<>();
                    hashmap.put("postid", postidnew);





                    return hashmap;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(view.getContext());
            requestQueue.add(stringRequest);
        }



    @Override
    public int getItemCount() {
        return postList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, postuser, textViewRating, textViewPrice,id;
        ImageView imageView,im2,proedit;
        EditText posttext,commenttext;
        ImageButton sendcomnt;

        public ProductViewHolder(View itemView) {
            super(itemView);
sendcomnt = itemView.findViewById(R.id.sendcomment);
commenttext = itemView.findViewById(R.id.commenttxt);
            posttext = itemView.findViewById(R.id.posttext);
            postuser = itemView.findViewById(R.id.postuser);
            id= itemView.findViewById(R.id.ids);

//            textViewRating = itemView.findViewById(R.id.textViewRating);
//            textViewPrice = itemView.findViewById(R.id.textViewPrice);
            imageView = itemView.findViewById(R.id.postedimg);
            proedit = itemView.findViewById(R.id.editdelpost);


        }
    }
}