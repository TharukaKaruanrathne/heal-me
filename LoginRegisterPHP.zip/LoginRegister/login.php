<?php


if (isset($_POST['user_name']) && isset($_POST['password'])) {
    $username = $_POST['user_name'];
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        echo "All fields are required";
    } else {
        $conn = mysqli_connect('localhost', 'root', '1234', 'healme');
// Check connections
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
					}



$query = "SELECT * FROM user WHERE user_name=
                '$username' AND password='$password'";
        $results = mysqli_query($conn, $query);
  
        // $results = 1 means that one user with the
        // entered username exists
        if (mysqli_num_rows($results) == 1) {
             
            echo 'Success';
        }
		else{
			echo 'Username or Password Wrong';
		}
		
		else{echo 'Database Connection error';}
		else{echo 'Database Load error';}


mysqli_close($conn);
    }
}

?>
