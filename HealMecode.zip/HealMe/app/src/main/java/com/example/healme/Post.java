package com.example.healme;

public class Post {
    String postid,Content,user_name,url;

    public Post() {
    }

    public Post(String content, String user_name,String url,String postid) {
        Content = content;
        this.user_name = user_name;
        this.url = url;
        this.postid = postid;
    }

    public String getUrl() {
        return url;
    }

    public String getPostid() {
        return postid;
    }

    public void setPostid(String postid) {
        this.postid = postid;
    } // This is a setter method for the "postid" attribute.
    // It allows you to set (update) the value of the "postid" attribute

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUser_name() {
        return user_name;
    }// This is a getter method for the "user_name" attribute.

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }// This is a setter method for the "user_name" attribute.

    public String getContent() {
        return Content;
    } // This is a getter method for the "Content" attribute.

    public void setContent(String content) {
        Content = content;
    }// This is a setter method for the "Content" attribute.
}
