<?php

if (isset($_POST['POSTTEXT'])&&isset($_POST['image'])&&isset($_POST['user_name'])) {
		
		
      $post =  $_POST['POSTTEXT'];
$image =  $_POST['image'];
$user_name = $_POST['user_name'];
$date = $_POST['user_name'];
$user_name = $_POST['user_name'];


$file = 'Images/'.date("Y-m-d").'-'.time().'-'.rand(10000,100000).'.jpg';

	  
	  if(file_put_contents($file,base64_decode($image))){
		  
	   $conn = mysqli_connect('localhost', 'root', '1234', 'healme');
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
		  
		  $sql = "INSERT INTO post (content,user_name)VALUES ('".$post."','".$user_name."');
		  		  INSERT INTO postimage (url,username)VALUES ('".$file."','".$user_name."')";

if ($conn->multi_query($sql) === true) {
  echo "success";
}



		
	  
	 } 
}
	



?>