package com.example.healme;

import android.content.Context;
import android.widget.Toast;

public class AndroidUtils {
    public static void makeToast(Context applicationContext, String toString) {
        Toast.makeText(applicationContext,toString,Toast.LENGTH_LONG).show();

    }

    public static String IP = "192.168.236.132";
}
