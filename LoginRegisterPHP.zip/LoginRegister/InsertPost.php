<?php

if (isset($_POST['POSTTEXT'])) {
		
		
      $post =  $_POST['POSTTEXT'];
	  $user_name =  $_POST['user_name'];
	  
	 
	   $conn = mysqli_connect('localhost', 'root', '1234', 'healme');
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO post (content,user_name)
VALUES ('".$post."','".$user_name."')";

if (mysqli_query($conn, $sql)) {
  echo "success";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

	  
	  
	  
    } 
	



?>