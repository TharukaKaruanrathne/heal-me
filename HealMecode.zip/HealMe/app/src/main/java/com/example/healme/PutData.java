package com.example.healme;

public class PutData {
    public PutData(String s, String post, String[] field, String[] data) {
    }

    public boolean startPut() {
        return false;
    }

    public boolean onComplete() {
        return false;
    }

    public boolean getResult() {

        return false;
    }
}