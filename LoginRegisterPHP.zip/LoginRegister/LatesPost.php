<?php

 $conn = mysqli_connect('localhost', 'root', '1234', 'healme');
 //creating a query
 $stmt = $conn->prepare("SELECT postid,content,user_name,url FROM post");
 
 //executing the query 
 $stmt->execute();
 
 $stmt->bind_result($postid,$content,$user_name,$url);
 
 
 $posts = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['postid'] = $postid; 
 
 $temp['content'] = $content; 

 $temp['user_name'] = $user_name; 
 $temp['url'] = $url; 
 
 
 
 array_push($posts, $temp);
 }
 echo json_encode($posts);
 
 
?>