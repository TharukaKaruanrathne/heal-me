package com.example.healme;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private String Url = "https://"+AndroidUtils.IP+"/loginRegister/Register.php";

    Button buttonRegister;
    EditText EditTextUserName, EditTextemail, EditTextPhoneNo, editTextpassword, EditTextcmfPassword;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditTextUserName = findViewById(R.id.user_name);
        EditTextemail = findViewById(R.id.email);
        EditTextPhoneNo = findViewById(R.id.phone_no);
        editTextpassword = findViewById(R.id.password);
        EditTextcmfPassword = findViewById(R.id.cmfPassword);
        buttonRegister = findViewById(R.id.buttonRegister);


        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //onRegister();
                save();
            }
        });
    }

    public void save() {


        if  (TextUtils.isEmpty(EditTextUserName.getText().toString())){
            EditTextUserName.setError("Username Cannot Blank");
            return;

        }


        if  (TextUtils.isEmpty(EditTextemail.getText().toString())){
            EditTextemail.setError("Email Cannot Blank");
            return;

        }
        if  (TextUtils.isEmpty(EditTextPhoneNo.getText().toString())){
            EditTextPhoneNo.setError("phone number Cannot Blank");
            return;

        }
        if  (TextUtils.isEmpty(editTextpassword.getText().toString())){
            editTextpassword.setError("password Cannot Blank");
            return;

        }
        if  (TextUtils.isEmpty(EditTextcmfPassword.getText().toString())){
            EditTextcmfPassword.setError("Confirm-password Cannot Blank");
            return;

        }
        if (!EditTextcmfPassword.getText().toString().matches(editTextpassword.getText().toString())){
            EditTextcmfPassword.setError("Two Password Mismatch");
            return;

        }
        HttpsTrustManager.allowAllSSL();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
        if(response.matches("success")){
            AndroidUtils.makeToast(getApplicationContext(),"Saved Success");
           startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
            finish();
            Clear();
        }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                AndroidUtils.makeToast(getApplicationContext(),error.getMessage());
            }
        }){
            @NonNull
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send username and password to the server
                Map<String, String> hashmap = new HashMap<>();
                hashmap.put("user_name", EditTextUserName.getText().toString());
                hashmap.put("email", EditTextemail.getText().toString());
                hashmap.put("phone_no", EditTextPhoneNo.getText().toString());
                hashmap.put("password", editTextpassword.getText().toString());
                hashmap.put("confirm_password", EditTextcmfPassword.getText().toString());


                return hashmap;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
public void Clear(){
   EditTextUserName.setText("");
   EditTextemail.setText("");
   EditTextPhoneNo.setText("");
   editTextpassword.setText("");
   EditTextcmfPassword.setText("");
}
    public void onRegister(View view){
        Intent intent=new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
      /*   buttonRegister.setOnClickListener(v -> {
        if (EditTextUserName.getText().toString().isEmpty() || EditTextemail.getText().toString().isEmpty() ||
                EditTextPhoneNo.getText().toString().isEmpty() || editTextpassword.getText().toString().isEmpty()
                || EditTextcmfPassword.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Enter the Data", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "User Name -  " + EditTextUserName.getText().toString() + " \n" +
                    "Email -  " + EditTextemail.getText().toString() + " \n" +
                    "Phone Number -  " + EditTextPhoneNo.getText().toString() + " \n" +
                    "Password -  "+ editTextpassword.getText().toString() + " \n" +
                    "Re-Enter Password -  "+ EditTextcmfPassword.getText().toString(), Toast.LENGTH_SHORT).show();

            save();
             }


        }); */
    }
//}